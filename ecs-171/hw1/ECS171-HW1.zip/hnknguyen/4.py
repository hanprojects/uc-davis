def pred_compare(X,Y,test_size):
  from sklearn import tree
  from statistics import mean
  from sklearn.ensemble import RandomForestClassifier
  from sklearn.model_selection import train_test_split
  from sklearn.ensemble import ExtraTreesClassifier
  from sklearn.tree import DecisionTreeClassifier
  from sklearn.metrics import accuracy_score

  nreps = test_size
  dt_acc = list(range(0,nreps))
  rf_acc = list(range(0,nreps))
  et_acc = list(range(0,nreps))
  knn_acc = list(range(0,nreps))
  pca_acc = list(range(0,nreps))

  for i in range(0,nreps):
  
    X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=test_size)
    import time

    ## Prediction for kNN
    start_time_knn = time.time()
    from sklearn.neighbors import KNeighborsRegressor
    knn = KNeighborsRegressor(n_neighbors=test_size)
    
    knn.fit(X_train, y_train)
    y_pred = knn.predict(X_test)
    knn_acc[i] = accuracy_score(y_test,y_pred)
    total_time_knn = time.time() - start_time_knn

    ## Prediction for PCA
    start_time_pca = time.time()
    from sklearn.neighbors import KNeighborsRegressor
    knn = KNeighborsRegressor(n_neighbors=test_size)
    from sklearn.decomposition import PCA
    pca = PCA(n_components=test_size)
    pca.fit(X_train)
    X_train_pca = pca.transform(X_train)
    knn.fit(X_train_pca, y_train)
    y_pred = knn.predict(X_test)
    pca_acc[i] = accuracy_score(y_test,y_pred)
    total_time_pca = time.time() - start_time_pca

    ## Prediction for Decision Tree
    start_time_dt = time.time()
    clf = tree.DecisionTreeClassifier()
    clf = clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    dt_acc[i] = accuracy_score(y_test, y_pred)
    total_time_dt = time.time() - start_time_dt

    ## Prediction for Random Forest
    start_time_rf = time.time()
    clf = RandomForestClassifier()
    clf = clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    rf_acc[i] = accuracy_score(y_test, y_pred)
    total_time_rf = time.time() - start_time_rf

    ## Prediction for Extra Tree
    start_time_et = time.time()
    clf = ExtraTreesClassifier()
    clf = clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    et_acc[i] = accuracy_score(y_test, y_pred)
    total_time_et = time.time() - start_time_et

  print("KNN prediction accuracy:", mean(knn_acc))
  print("KNN runtime:", total_time_knn)

  print("PCA prediction accuracy:", mean(pca_acc))
  print("PCA runtime:", total_time_pca)

  print("DT prediction accuracy:", mean(dt_acc))
  print("DT runtime:", total_time_dt)

  print("RF prediction accuracy:", mean(rf_acc))
  print("RF runtime:", total_time_rf)

  print("ET prediction accuracy:", mean(et_acc))
  print("ET runtime:", total_time_et)

# =================== MAIN FUNCTION ======================= #
import pandas as pd
import numpy as np

my_path = '/content/drive/My Drive/ecs171_yancey/Lecture_Notes/Chapter_4/covtype.data'
covtype = pd.read_csv(my_path)
X = covtype.iloc[:,0:5]
Y = covtype.iloc[:,6]

# pred_compare(X,Y,3)