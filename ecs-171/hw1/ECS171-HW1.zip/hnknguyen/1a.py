# ============== pcaCompare FUNCTION =============== #
def pcaCompare(X,Y,rows,k,pcs):
  import time
  
## Get computation time & prediction accuracy of the kNN
  knn_times = []
  knn_pred_acc = []
  
  for i in range(len(rows)):
    start_time = time.time()
    knnout, nn = kNN(X,Y,rows[i],k,regress=True)
    total_time = time.time() - start_time
    knn_time.append(total_time)

    for j in range(len(knnout)):
      Y_pred = knnout[i][j]
      Y_actual = Y.iloc[i]
      pred_acc = float(Y_pred / Y_actual)
      knn_pred_acc.append(pred_acc)
  
## Get computation time & prediction accuracy of the kNN using PCA
  from sklearn.preprocessing import StandardScaler
  scaler = StandardScaler()
  scaler.fit(X)

  X = scaler.transform(X)
  newx = scaler.transform(newx)

  from sklearn.decomposition import PCA
  pca = PCA(n_components=pcs)
  pca.fit(X)

  X_pca = pca.transform(X)
  rows_pca = pca.transform(rows)

  from sklearn.neighbors import KNeighborsRegressor
  knn = KNeighborsRegressor(n_neighbors=50)
  knn.fit(X_pca, Y)

  pca_times = []
  pca_pred_acc = []
  pca_variance = []

  for i in range(len(rows_pca)):
    start_time = time.time()
    pca_pred = knn.predict(rows_pca[i])
    total_time = time.time() - start_time()
    pca_times.append(total_time)

    pred_acc = float(pca_pred / Y[i])
    pca_pred_acc.append(pred_acc)
    
    import statistics
    pca_var = statistics.variance(pca_pred)
    pca_variance.append(pca_var)

## Compute change between kNN and PCA time & prediction accuracy
  time_change = []
  pred_acc_change = []
  for i in range(len(rows)):
    t_change = knn_times[i] - pca_times[i]
    time_change.append(t_change)

    pa_change = knn_pred_acc[i] - pca_pred_acc[i]
    pred_acc_change.append(pa_change)

## Make a 2D array
  zipped = list(zip(time_change, pred_acc_change, pca_variance))
  import pandas as pd
  table = pd.Dataframe(zipped, columns=['Time change', 'Pred Accuracy Change', 'Variance'], index=range(zipped))
  print(table)


# ====================== kNN FUNCTION ======================= #
def kNN(X,Y,newx,k,regress=True,allK=False,leave1out=False,scaleX=True,scaler='standard'):

  import warnings
  warnings.filterwarnings('ignore')

  import numpy as np
  import pandas as pd

  from sklearn.neighbors import KNeighborsClassifier 
  from sklearn.neighbors import KNeighborsRegressor

  from sklearn.preprocessing import StandardScaler
  #from sklearn.preprocessing import MinMaxScaler
  #from sklearn.preprocessing import RobustScaler

  from statistics import mean 
  from statistics import mode
  from collections import Counter

  def kNNtype(neighbs,regress):
    if regress:
      knn = KNeighborsRegressor(n_neighbors=neighbs)
    else:
      knn = KNeighborsClassifier(n_neighbors=neighbs)
    return knn

  if scaler != 'standard':
    scaler = scaler
  else:
    scaler = StandardScaler()

# Update: for row subsets/test sets in hw; fitting the scaing function should be done separate
# so the same can be applied to train and test data (or X and newx) 
  if scaleX == True:
    # scale should be fit to X/train
    scaler.fit(X)
    columns_X = [list(X.columns)]
    for feature in columns_X:
      X[feature] = scaler.transform(X[feature])
      newx[feature] = scaler.transform(newx[feature])

  knn_all = pd.DataFrame()
  if allK == True:
    if leave1out == True:
      nn_all = []
      for j in list(newx.index.values.tolist()):
      #for j in list(Y.index.values.tolist()):
        knn_row = []
        knn = kNNtype(k+1,regress)
        knn.fit(X, Y)
        test = pd.DataFrame(newx.loc[j,:])
        nn = knn.kneighbors(test.T)[1][0]
        for i in range(2,k+1):
          nn1 = nn[1:i] # leave one out
          test = list(Y.iloc[nn1])
          if regress:
            test = mean(test)
          else:
            c = Counter(test)
            l = list(c.values())
            ind = l.index(max(c.values()))
            test = list(c.keys())[ind]
            # count number of times the max class occurs and if there is a tie
            # choose the second class with the max if index is even
            if (l.count(max(l))) > 1 and (j % 2 !=0):
              l[ind] = 0
              ind = l.index(max(c.values()))
              test = list(c.keys())[ind]

          knn_row.append(test)
        knn_row = pd.DataFrame(knn_row)
        knn_all = [knn_all, knn_row]
        knn_all = pd.concat(knn_all,axis=1, ignore_index=True)
        nn_all.append(list(nn1))
      nn_all = np.array(nn_all)
    else:
        for i in range(1,k+1):
          knn = kNNtype(i,regress)
          knn.fit(X, Y)
          test = knn.predict(newx)
          knn_row = pd.DataFrame(test).T
          knn_all = [knn_all, knn_row]
          knn_all = pd.concat(knn_all,axis=0, ignore_index=True)
        nn_all = knn.kneighbors(newx)[1]
  else:
    if leave1out == True:
      knn_row = []
      for j in list(newx.index.values.tolist()):
      #for j in list(Y.index.values.tolist()):
        knn = kNNtype(k,regress)
        knn.fit(X, Y)
        test = pd.DataFrame(newx.loc[j,:])
        nn = knn.kneighbors(test.T)[1][0]
        nn1 = nn[1:len(nn)]

        test = list(Y.iloc[nn1])
        if regress:
            test = mean(test)
        else:
          c = Counter(test)
          l = list(c.values())
          ind = l.index(max(c.values()))
          test = list(c.keys())[ind]
          # count number of times the max class occurs and if there is a tie
          # choose the second class with the max if index is even
          if (l.count(max(l))) > 1 and (j % 2 !=0):
            l[ind] = 0
            ind = l.index(max(c.values()))
            test = list(c.keys())[ind]

        knn_row.append(test)
      knn_all = pd.DataFrame(knn_row).T
      nn_all = nn1
    else:
        knn = kNNtype(k,regress)
        knn.fit(X, Y)
        test = knn.predict(newx)
        knn_all = pd.DataFrame(test)
        nn_all = knn.kneighbors(newx)[1]

  return knn_all, nn_all

# ================ MAIN FUNCTION ==================== #
import pandas as pd
import numpy as np

my_path = '/content/drive/My Drive/ecs171_yancey/Lecture_Notes/Chapter_3/YearPredictionMSD.txt'
ms = pd.read_csv(my_path, header=None)

X = ms.iloc[:,1:]
Y = ms.iloc[:,0]
newx = X.iloc[0:1,:]

# pcaCompare(X,Y,newx,20,20)