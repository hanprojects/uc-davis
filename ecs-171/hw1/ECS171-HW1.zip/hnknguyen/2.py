def tree(X,Y,start_node):

  clf = tree.DecisionTreeRegressor()
  clf = clf.fit(X, Y)

  from sklearn.tree import _tree
  my_tree = clf.my_tree

  feature = my_tree.feature
  feature_names = X.columns.tolist()[1:]
  children_left = my_tree.children_left[start_node]
  children_right = my_tree.children_right[start_node]
  value = my_tree.value[start_node]
  threshold = my_tree.threshold[start_node]
  
  new_list = [threshold, value]

  for i in range(children_left)):
    for j in range(len(new_list)):
      far_left_branch = X[(X[feature_names[j]] < new_list[j]) & (X[feature_names[j+1]] < new_list[j+1])]
      y_pred_left = clf.predict(far_left_branch.iloc[:,1:])
  
    for i in range(children_right):
      for j in range(len(new_list)):
        far_right_branch = X[(X[feature_names[j]] > new_list[j]) & (X[feature_names[j+1]] > new_list[j+1])]
        y_pred_right = clf.predict(far_right_branch.iloc[:,1:])
 
  return y_pred_left, y_pred_right

# ===================== MAIN FUNCTION ====================== #
import pandas as pd
import numpy as np
### INSERT YOUR PATH to data HERE: ###
my_path = '/content/drive/My Drive/ecs171_yancey/Lecture_Notes/Chapter_4/airq'

# load CSV using pandas library
airq = pd.read_csv(my_path)
X = airq.iloc[:,1:]
Y = pd.DataFrame(airq.iloc[:,0])

# tree(X,Y,0)