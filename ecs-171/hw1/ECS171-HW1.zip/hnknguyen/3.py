def graph_plot(min_leaf, X, Y): 
  from sklearn import tree

  from sklearn.model_selection import train_test_split
  x_train, x_test, y_train, y_test = train_test_split(pd.DataFrame(X), pd.DataFrame(Y), test_size=0.25)

  all = pd.DataFrame()

  for minleaf in min_leaf:
    clf = tree.DecisionTreeRegressor(min_samples_leaf=minleaf)
    clf = clf.fit(x_train, y_train)
    y_pred = clf.predict(x_test)
    y_actual = clf.predict(y_test)
    pred_acc = float(y_pred/y_actual)
    row = pd.Dataframe(pred_acc)
    all = [all, row]
    all = pd.concat(all,axis=0,ignore_index=True)

  from matplotlib.legend_handler import HandlerLine2D
  plt.plot(min_splits, all,  label="Pred Accuracy")
  plt.ylabel('Prediction Accuracy')
  plt.xlabel('min samples left')
  plt.show()

# ======================= MAIN FUNCTION ===========================# 

import pandas as pd
import numpy as np

my_path = '/content/drive/My Drive/ecs171_yancey/Lecture_Notes/Chapter_4/train.csv'
train = pd.read_csv(my_path, parse_dates =['pickup_datetime'])

X = train.iloc[:,1:]
Y = train.iloc[:,0]
min_leaf = np.linspace(0.1, 1.0, 10, endpoint=True)

# graph_plot(min_leaf, X, Y)