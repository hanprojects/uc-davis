import math

def pcaOptimize(X,Y,rows,k,pcs,maxLoss):
  import time
  
## Get computation time & prediction accuracy of the kNN
  knn_times = []
  knn_pred_acc = []
  
  for i in range(len(rows)):
    start_time = time.time()
    knnout, nn = kNN(X,Y,rows[i],k,regress=True)
    total_time = time.time() - start_time
    knn_time.append(total_time)

    for j in range(len(knnout)):
      Y_pred = knnout[i][j]
      Y_actual = Y.iloc[i]
      pred_acc = float(Y_pred / Y_actual)
      knn_pred_acc.append(pred_acc)
  
## Get computation time & prediction accuracy of the kNN using PCA
  from sklearn.preprocessing import StandardScaler
  scaler = StandardScaler()
  scaler.fit(X)

  X = scaler.transform(X)
  newx = scaler.transform(newx)

  from sklearn.decomposition import PCA
  pca = PCA(n_components=pcs)
  pca.fit(X)

  X_pca = pca.transform(X)
  rows_pca = pca.transform(rows)

  from sklearn.neighbors import KNeighborsRegressor
  knn = KNeighborsRegressor(n_neighbors=50)
  knn.fit(X_pca, Y)

  pca_times = []
  pca_pred_acc = []
  pca_variance = []

  for i in range(len(rows_pca)):
    start_time = time.time()
    pca_pred = knn.predict(rows_pca[i])
    total_time = time.time() - start_time()
    pca_times.append(total_time)

    pred_acc = float(pca_pred / Y[i])
    pca_pred_acc.append(pred_acc)
    
    import statistics
    pca_var = statistics.variance(pca_pred)
    pca_variance.append(pca_var)

## Compute change between kNN and PCA time & prediction accuracy
  time_change = []
  pred_acc_change = []
  avg_loss = []
  for i in range(len(rows)):
    t_change = knn_times[i] - pca_times[i]
    time_change.append(t_change)

    pa_change = knn_pred_acc[i] - pca_pred_acc[i]
    pred_acc_change.append(pa_change)

    loss = float(1 + pa_change)
    avg_loss.append(loss)

## Merge 2 lists to an 2D array
array = []
array.append(range(0,6))
array.append(avg_loss)
array.append(pca_times)

for i in range(0,6):
  for j in range(len(avg_loss)):
    if j < maxLoss:
      for k in range(len(pca_times)):
        if k == min(pca_times):
          best_pc = i

print(best_pc)

# ================ MAIN FUNCTION ==================== #
import pandas as pd
import numpy as np

my_path = '/content/drive/My Drive/ecs171_yancey/Lecture_Notes/Chapter_3/YearPredictionMSD.txt'
ms = pd.read_csv(my_path, header=None)

X = ms.iloc[:,1:]
Y = ms.iloc[:,0]
newx = X.iloc[0:1,:]

# pcaOptimize(X,Y,newx,20,20,1.1)