library(regtools)
data(day)
# head(day)
d <- day[c('temp','atemp','hum','windspeed','casual','registered','cnt')]
lmout <- lm(cnt ~ .,data=d)
xd = preprocessx(d[,-5],10)
knnout <- knnest(d$cnt,xd,10)
parvsnonparplot(lmout,knnout)