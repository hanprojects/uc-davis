import pandas as pd
import numpy as np

## atRisk(rows,k,path)
def atRisk(rows,k,path):
    vert = pd.read_csv(path,sep=' ',header=None)
    
    # set X and Y with labels 0, 1 or 2
    X = vert.iloc[:,0:6]
    from sklearn.preprocessing import LabelEncoder
    le = LabelEncoder()
    vert.iloc[:,6] = le.fit_transform(vert.iloc[:,6])
    Y = vert.iloc[:,6]

    # Get knnout, nn via kNN function
    knnout, nn = kNN(X,Y,X,len(rows),regress=False,allK=True,leave1out=True)

    # Predict probability of risk
    x = knnout.values == Y.astype(float).values
    probs = x.sum(axis=1)/len(Y)
    y = max(probs).tolist()
    test = probs==y
    
    knn = KNeighborsClassifier(n_neighbors = len(rows))
    knn.fit(X,Y)
    test = pd.DataFrame(X.iloc[0:11,:])
    array = knn.predict_proba(test)

    # Loop through 2D array to check categories: 
    for i in range(0,len(array)):
        for j in range(0,len(array[0])):
            if array[i][j] < 0.3:
                array[i][j] = 0
            elif array[i][j] >= 0.3 and array[i][j] < 0.5: 
                array[i][j] = 2
            elif array[i][j] >= 0.5:
                array[i][j] = 1
    
    # Display array
    print(array)


## kNN FUNCTION:
def kNN(X,Y,newx,k,regress=True,allK=False,leave1out=False,scaleX=True,scaler='standard'):

    import warnings
    warnings.filterwarnings('ignore')

    import numpy as np

    from sklearn.neighbors import KNeighborsClassifier 
    from sklearn.neighbors import KNeighborsRegressor

    from sklearn.preprocessing import StandardScaler
    from sklearn.preprocessing import MinMaxScaler
    from sklearn.preprocessing import RobustScaler

    from statistics import mean 
    from statistics import mode
    from collections import Counter

    def kNNtype(neighbs,regress):
        if regress:
            knn = KNeighborsRegressor(n_neighbors=neighbs)
        else:
            knn = KNeighborsClassifier(n_neighbors=neighbs)
        return knn

    if scaler != 'standard':
        scaler = scaler
    else:
        scaler = StandardScaler()

# Update: for row subsets/test sets in hw; fitting the scaling function should be done separate,
# so the same can be applied to train and test data (or X and newx) 
    if scaleX == True:
        # scale should be fit to X/train
        scaler.fit(X)
        newx = pd.DataFrame(scaler.transform(newx))
        X = pd.DataFrame(scaler.transform(X))

    knn_all = pd.DataFrame()
    if allK == True:
        if leave1out == True:
            nn_all = []
            for j in list(newx.index.values.tolist()):
            #for j in list(Y.index.values.tolist()):
                knn_row = []
                knn = kNNtype(k+1,regress)
                knn.fit(X, Y)
                test = pd.DataFrame(newx.loc[j,:])
                nn = knn.kneighbors(test.T)[1][0]
                for i in range(2,k+1):
                    nn1 = nn[1:i] # leave one out
                    test = list(Y.iloc[nn1])
                    if regress:
                        test = mean(test)
                    else:
                        c = Counter(test)
                        l = list(c.values())
                        ind = l.index(max(c.values()))
                        test = list(c.keys())[ind]
                        # count number of times the max class occurs and if there is a tie
                        # choose the second class with the max if index is even
                        if (l.count(max(l))) > 1 and (j % 2 !=0):
                            l[ind] = 0
                            ind = l.index(max(c.values()))
                            test = list(c.keys())[ind]

                    knn_row.append(test)
                
                knn_row = pd.DataFrame(knn_row)
                knn_all = [knn_all, knn_row]
                knn_all = pd.concat(knn_all,axis=1, ignore_index=True)
                nn_all.append(list(nn1))
            nn_all = np.array(nn_all)
        
        else:
            for i in range(1,k+1):
                knn = kNNtype(i,regress)
                knn.fit(X, Y)
                test = knn.predict(newx)
                knn_row = pd.DataFrame(test).T
                knn_all = [knn_all, knn_row]
                knn_all = pd.concat(knn_all,axis=0, ignore_index=True)
            n_all = knn.kneighbors(newx)[1]
    
    else:
        if leave1out == True:
            knn_row = []
            for j in list(newx.index.values.tolist()):
            # for j in list(Y.index.values.tolist()):
                knn = kNNtype(k,regress)
                knn.fit(X, Y)
                test = pd.DataFrame(newx.loc[j,:])
                nn = knn.kneighbors(test.T)[1][0]
                nn1 = nn[1:len(nn)]

                test = list(Y.iloc[nn1])
                if regress:
                    test = mean(test)
                else:
                    c = Counter(test)
                    l = list(c.values())
                    ind = l.index(max(c.values()))
                    test = list(c.keys())[ind]
                    # count number of times the max class occurs and if there is a tie
                    # choose the second class with the max if index is even
                    if (l.count(max(l))) > 1 and (j % 2 !=0):
                        l[ind] = 0
                        ind = l.index(max(c.values()))
                        test = list(c.keys())[ind]

                knn_row.append(test)
            
            knn_all = pd.DataFrame(knn_row).T
            nn_all = nn1
        
        else:
            knn = kNNtype(k,regress)
            knn.fit(X, Y)
            test = knn.predict(newx)
            knn_all = pd.DataFrame(test)
            nn_all = knn.kneighbors(newx)[1]

    return knn_all, nn_all
